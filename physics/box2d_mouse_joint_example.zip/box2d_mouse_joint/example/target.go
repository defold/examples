embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"target\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/assets/sprites.atlas\"\n"
  "}\n"
  ""
  scale {
    x: 0.46
    y: 0.46
    z: 1.0
  }
}
